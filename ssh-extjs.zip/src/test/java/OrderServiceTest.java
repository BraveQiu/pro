import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssh.demo.order.entity.Order;
import com.ssh.demo.order.service.IOrderService;
import com.ssh.demo.util.enums.Level;


public class OrderServiceTest {
	//@Test
	@Before
	public void initData() {
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml",
				"applicationContext-jpa.xml");
		IOrderService orderService = (IOrderService) context.getBean("orderService");
		for(int i=0;i<100;i++) {
			Order order = new Order();
			order.setOrderNumber("NO."+i);
			order.setCreateTime(new Date());
			if(i%2==0) {
				order.setLevel(Level.HIGH);
			}else if(i%3==0) {
				order.setLevel(Level.MEDIUM);
			}else {
				order.setLevel(Level.LOW);
			}
			order.setPrice((float)Math.random()*10000);
			orderService.save(order);
		}
	}
	@Test
	public void testFindAll() {
		
	}
	
}
