package com.ssh.demo.order.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssh.demo.order.entity.Order;
import com.ssh.demo.order.service.IOrderService;
import com.ssh.demo.util.web.ExtjsPageable;
@Controller
@RequestMapping("/order")
public class OrderController {
	@Autowired
	private IOrderService orderService;
	// order/findAll
	@RequestMapping("/findAll")
	public @ResponseBody List<Order> findAll(){
		return orderService.findAll();
	}
	// order/findPage?page=0&size=25
	@RequestMapping("/findPage")
	public @ResponseBody Page<Order> findAll(ExtjsPageable pageable){
		return orderService.findAll(pageable.getPageable());
	}
	@RequestMapping("/saveOrUpdate")
	public @ResponseBody String saveOrUpdate(Order order){
		try {
			orderService.save(order);
			return "success:true";
		} catch (Exception e) {
			e.printStackTrace();
			return "success:false";
		}
	}
}
