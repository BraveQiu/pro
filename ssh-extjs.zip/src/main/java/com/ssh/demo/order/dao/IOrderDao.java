package com.ssh.demo.order.dao;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.ssh.demo.order.entity.Order;


/**
 * 抽象接口
 * @author Brave Qiu
 *
 */
//public interface IOrderDao extends IBaseDao<Order, Long>{
//}
public interface IOrderDao extends PagingAndSortingRepository<Order, Long>{
	public Order save(Order order);
//	public Order findById(Long id); 
	
/**
 * CrudRepository接口方法：	
 */
//	对象集合 orderDao.save(集合);//saveOrUpdate
//	对象  orderDao.save(Object object);//saveOrUpdate
//	void orderDao.delete(Object集合);
//	void orderDao.delete(Long id);
//	void orderDao.delete(Object object);
//	void orderDao.deleteAll();
//	对象集合 orderDao.findAll();
//	对象集合 orderDao.findAll(id集合);
//	对象 orderDao.findOne(Long id);
//	boolean orderDao.exists(Long id);
//	int orderDao.count();//总记录数  
	
/**
 * PagingAndSortingRepository接口方法：	
 */
//	Page<Order> findAll(Pageable pageable);//分页+排序查询
//	List<Order> findAll(Sort sort);//排序查询
	
/**
 * Specification	
 */
//Page<Order> findAll(Pageable pageable,Specification specification);
	
	/**
	 *	自定义方法 ：
	 */
	
	
}
