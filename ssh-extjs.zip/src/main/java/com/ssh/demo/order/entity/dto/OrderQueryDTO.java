package com.ssh.demo.order.entity.dto;

import java.util.Date;
/**
 * 封装前端提交查询条件字段
 * 提供查询条件组装的静态方法
 * @author Administrator
 *
 */
public class OrderQueryDTO {
	private String orderNumber;
	private Date createTime;
	private String level;
	private float price;
	public String getOrderNumber() {
		return orderNumber;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public String getLevel() {
		return level;
	}
	public float getPrice() {
		return price;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	
}
