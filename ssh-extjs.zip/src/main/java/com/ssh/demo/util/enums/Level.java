package com.ssh.demo.util.enums;

public enum Level {
	HIGH,MEDIUM,LOW
}
