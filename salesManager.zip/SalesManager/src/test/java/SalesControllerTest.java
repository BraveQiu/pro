import java.util.Date;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mall.sales.entity.SalesInfo;
import com.mall.sales.service.ISalesService;
import com.mall.stock.entity.StockInfo;
import com.mall.stock.service.IStockService;

public class SalesControllerTest {
	@Test
	public void initData() {
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml",
				"applicationContext-jpa.xml");
		ISalesService salesService = (ISalesService) context.getBean("salesService");
		for(int i=0;i<50;i++) {
			SalesInfo salesInfo = new SalesInfo();
			salesInfo.setGoodsId("52O000004"+i);
			salesInfo.setCreateTime(new Date());
			float price = 0;
			int salesCount =0;
			if(i%2==0) {
				salesInfo.setGoodsName("统一奶茶");
				price = (float)Math.random()*20;
				salesCount = 2;
				salesInfo.setSalesCount(salesCount);
				salesInfo.setSalesHandler("刘小峰");
			}else if(i%3==0) {
				salesInfo.setGoodsName("加多宝");
				price = (float)Math.random()*30;
				salesCount = 3;
				salesInfo.setSalesCount(salesCount);
				salesInfo.setSalesHandler("容小深");
			}else {
				salesInfo.setGoodsName("火腿");
				price = (float)Math.random()*50;
				salesCount = 1;
				salesInfo.setSalesCount(salesCount);
				salesInfo.setSalesHandler("梁小福");
			}
			salesInfo.setPrice(price);
			salesInfo.setSalesNumber("ISO000034"+i);
			salesInfo.setTotal((float)price*salesCount);
			System.out.println("total:"+(float)price*salesCount);
			salesService.save(salesInfo);
		}
	}
	@Test
	public void initData2() {
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml",
				"applicationContext-jpa.xml");
		IStockService stockService = (IStockService) context.getBean("stockService");
		for(int i=0;i<50;i++) {
			StockInfo stockInfo = new StockInfo();
			stockInfo.setGoodsId("52O000004"+i);
			stockInfo.setStockTime(new Date());
			float price = 0;
			int stockCount =0;
			if(i%2==0) {
				stockInfo.setGoodsName("统一奶茶");
				price = (float)Math.random()*20;
				stockCount = 2;
				stockInfo.setStockCount(stockCount);
				stockInfo.setStockHandler("刘小峰");
			}else if(i%3==0) {
				stockInfo.setGoodsName("加多宝");
				price = (float)Math.random()*30;
				stockCount = 3;
				stockInfo.setStockCount(stockCount);
				stockInfo.setStockHandler("容小深");
			}else {
				stockInfo.setGoodsName("火腿");
				price = (float)Math.random()*50;
				stockCount = 1;
				stockInfo.setStockCount(stockCount);
				stockInfo.setStockHandler("梁小福");
			}
			stockInfo.setPrice(price);
			stockInfo.setStockNumber("ISO000034"+i);
			stockInfo.setTotal((float)price*stockCount);
			System.out.println("total:"+(float)price*stockCount);
			//stockService.save(stockInfo);
		}
	}
}
