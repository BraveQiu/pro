package com.ssh.demo.order.service;
/**
 * 业务层
 * 		抽象耦合
 * 		上层调用下层接口
 * @author Brave Qiu
 * 
 */

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssh.demo.order.dao.IOrderDao;
import com.ssh.demo.order.entity.Order;


@Service
@Transactional
public class OrderService implements IOrderService {
	// 1.依赖关系
	@Autowired
	//@Resource(name="")
	private IOrderDao orderDao;

	public Order save(Order order) {
		return orderDao.save(order);
	}

	public List<Order> save(List<Order> orderLists) {

		return (List<Order>) orderDao.save(orderLists);
	}

	public void delete(Order order) {
		orderDao.delete(order);
	}

	public void delete(Long id) {
		orderDao.delete(id);

	}

	public void delete(List<Order> orderLists) {
		orderDao.delete(orderLists);

	}

	public void deleteAll() {
		orderDao.deleteAll();

	}

	@Transactional(readOnly = true)
	public List<Order> findAll() {
		return (List<Order>) orderDao.findAll();
	}

	@Transactional(readOnly = true)
	public List<Order> findAll(List<Long> ids) {

		return (List<Order>) orderDao.findAll(ids);
	}

	@Transactional(readOnly = true)
	public Order findOne(Long id) {
		return orderDao.findOne(id);
	}

	@Transactional(readOnly = true)
	public boolean exists(Long id) {
		return orderDao.exists(id);
	}

	@Transactional(readOnly = true)
	public long count() {
		return orderDao.count();
	}

	@Transactional(readOnly = true)
	public Page<Order> findAll(Pageable pageable) {
		return orderDao.findAll(pageable);
	}

	@Transactional(readOnly = true)
	public List<Order> findAll(Sort sort) {
		return (List<Order>) orderDao.findAll(sort);
	}
}
