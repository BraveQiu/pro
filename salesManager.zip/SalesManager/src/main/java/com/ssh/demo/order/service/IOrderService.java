package com.ssh.demo.order.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.ssh.demo.order.entity.Order;


/**
 * service接口
 * @author Brave Qiu
 *
 */
public interface IOrderService {
//	public void save(Order order);
//	public void update(Order order);
//	public void delete(Order order);
//	
//	public Order findOne(Long id);
//	public List<Order> findAll();
	public Order save(Order order);
	public List<Order> save(List<Order> orderLists);
	
	public void delete(Order order);
	public void delete(Long id);
	public void delete(List<Order> orderLists);
	public void deleteAll();
	
	public List<Order> findAll();
	public List<Order> findAll(List<Long> ids);
	public Order findOne(Long id);

	public boolean exists(Long id);
	public long     count();//总记录数  
	
//	//分页+排序查询
	public Page<Order> findAll(Pageable pageable);
	//排序查询
	public List<Order> findAll(Sort sort);
}
