package com.mall.util.web;
/**
 * 销售查询条件
 * @author Brave Qiu
 *
 */


import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.stereotype.Component;
//@Component
public class QueryCondition {
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date beginTime;//开始时间
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date endTime;//结束时间
	private String goodsName;//查询商品
	private int page = 1;
	private int limit = 25;
	private String sort = "id";
	private String dir = "DESC";
	
	
	
	
	public Date getBeginTime() {
		return beginTime;
	}
	//@DateTimeFormat(pattern = "yyyy/MM/dd")
	public void setBeginTime(Date beginTime) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		this.beginTime = beginTime;
		System.out.println("begin----------"+sdf.format(beginTime));
	}
	
	public Date getEndTime() {
		return endTime;
	}
	//@DateTimeFormat(pattern = "yyyy/MM/dd")
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	
	
	public void setPage(int page) {
		this.page = page;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	public void setSort(String sort) {
		this.sort = sort;
	}
	public void setDir(String dir) {
		this.dir = dir;
	}
	public Pageable getPageable() {
		
		Pageable pageable = null;
		if(!sort.trim().equals("")&&!dir.trim().equals("")) {
			Sort pageSort = new Sort(Direction.DESC,sort);
			if(!dir.equals("DESC")) {
				pageSort = new Sort(Direction.ASC, sort); 
			}
			pageable = new PageRequest(page-1, limit,pageSort);
		}else {
			pageable = new PageRequest(page-1, limit);
		}
		return pageable;
	}
	
}
