package com.mall.sales.entity.dto;

import java.util.Date;

import org.springframework.beans.BeanUtils;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mall.sales.entity.SalesInfo;

/**
 * 针对UI设计的DTO（数据传输对象）
 * 用途：
 * 	返回给View：按需封装（一个Entity/多个Entity）的数据。
 *  接收View（form）提交的数据。
 * 	维护Entity对象之间的关联关系。
 * 	对比Entity没有持久化状态
 * @author Brave Qiu
 *
 */
public class SalesDTO {
	private Long id;
	private String salesNumber;//单据号
	private Date createTime;//开单时间
	private String goodsId;//商品编号
	private String goodsName;//商品名称
	private float price;//商品单价
	private Integer salesCount;//销售数量
	private float total;//总金额
	private String salesHandler;//经办人
	
	
	private float allTotal;//总收入,自定义字段，这个字段在数据库中没有，又后台统计

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSalesNumber() {
		return salesNumber;
	}

	public void setSalesNumber(String salesNumber) {
		this.salesNumber = salesNumber;
	}
	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss",timezone = "GMT+8")
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Integer getSalesCount() {
		return salesCount;
	}

	public void setSalesCount(Integer salesCount) {
		this.salesCount = salesCount;
	}

	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

	public String getSalesHandler() {
		return salesHandler;
	}

	public void setSalesHandler(String salesHandler) {
		this.salesHandler = salesHandler;
	}

	public float getAllTotal() {
		return allTotal;
	}

	public void setAllTotal(float allTotal) {
		this.allTotal = allTotal;
	}
	
	public static void dtoToEntity(SalesDTO dto,SalesInfo salesInfo) {
		BeanUtils.copyProperties(dto, salesInfo);
		//维护关系
		
	}
	public static void entityToDto(SalesInfo salesInfo,SalesDTO dto) {
		BeanUtils.copyProperties(salesInfo, dto);
		
	}
}
