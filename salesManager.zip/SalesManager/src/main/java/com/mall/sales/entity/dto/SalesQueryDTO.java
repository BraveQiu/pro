package com.mall.sales.entity.dto;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

import com.mall.sales.entity.SalesInfo;

/**
 * 
 * @author Brave Qiu
 *
 */
public class SalesQueryDTO {
	@DateTimeFormat(iso=ISO.DATE)
	private Date beginTime;	
	@DateTimeFormat(iso=ISO.DATE)
	private Date endTime;
	private String goodsName;
	public Date getBeginTime() {
		return beginTime;
	}
	public void setBeginTime(Date beginTime) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		beginTime = java.sql.Date.valueOf(sdf.format(beginTime));
		this.beginTime = beginTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();  
		c.setTime(java.sql.Date.valueOf(sdf.format(endTime)));  
		c.add(Calendar.DAY_OF_MONTH, 1);
      	Date endTime2 = c.getTime(); //日期加1
		this.endTime = endTime2;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	
	public static Specification<SalesInfo> getWhereClause(final SalesQueryDTO condetion){
		return new Specification<SalesInfo>() {
			@Override
			public Predicate toPredicate(Root<SalesInfo> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<Predicate> pList =  new ArrayList<Predicate>();
				if(condetion.getBeginTime()!=null) {
					Predicate p1 = cb.greaterThanOrEqualTo(root.get("createTime").as(Date.class) , condetion.getBeginTime());
					pList.add(p1);
				}
				if(condetion.getEndTime()!=null) {
					Predicate p2 = cb.lessThanOrEqualTo(root.get("createTime").as(Date.class) , condetion.getEndTime());
					pList.add(p2);
				}
				if(condetion.getGoodsName()!=null && condetion.getGoodsName().trim().length()>0) {
					Predicate p3 = cb.like(root.get("goodsName").as(String.class) , "%"+condetion.getGoodsName()+"%");
					pList.add(p3);
				}
				Predicate[] pArray = new Predicate[pList.size()];
				return cb.and(pList.toArray(pArray));
			}
		};	
	}

	
}
