package com.mall.sales.web;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.mall.sales.entity.SalesInfo;
import com.mall.sales.entity.dto.SalesDTO;
import com.mall.sales.entity.dto.SalesQueryDTO;
import com.mall.sales.service.ISalesService;
import com.mall.util.web.ExtjsPageable;
import com.mall.util.web.QueryCondition;


/**
 * 
 * @author Brave Qiu
 *
 */
@Controller
@RequestMapping("/sales")
public class SalesController {
	@Autowired
	private ISalesService salesService;
	
	// sales/findPage?page=0&size=25
	@RequestMapping("/findPage")
	public @ResponseBody Page<SalesDTO> findAll(SalesQueryDTO salesQueryDTO,ExtjsPageable pageable){
		System.out.println("beginTime:-----"+salesQueryDTO.getBeginTime());
		Page<SalesDTO> pages = salesService.findAll(SalesQueryDTO.getWhereClause(salesQueryDTO), pageable.getPageable());
		List<SalesDTO> lists = new ArrayList<>();
		List<SalesDTO> listBack = new ArrayList<>();
		float allTotal = 0;
		for(int i=1;i<=pages.getTotalPages();i++) {
			pageable.setPage(i);
			Page<SalesDTO> p = salesService.findAll(SalesQueryDTO.getWhereClause(salesQueryDTO), pageable.getPageable());
			lists.addAll(p.getContent());
		}
		for(SalesDTO s:lists) {
			allTotal = allTotal+s.getTotal();
		}
		SalesDTO dto = new SalesDTO();
		dto.setAllTotal(allTotal);
		
		listBack.add(dto);
		listBack.addAll(pages.getContent());
		return new PageImpl<>(listBack, pageable.getPageable(), pages.getTotalElements());
		//return salesService.findAll(SalesQueryDTO.getWhereClause(salesQueryDTO), pageable.getPageable());
	}
	
//	@RequestMapping("/findByCondition")
//	public @ResponseBody Page<SalesInfo> findByCondition(QueryCondition condition){
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        //java.sql.Date.valueOf(sdf.format(condition.getEndTime()))转换成特定格式的Util.Date
//		Calendar c = Calendar.getInstance();  
//        c.setTime(java.sql.Date.valueOf(sdf.format(condition.getEndTime())));  
//        c.add(Calendar.DAY_OF_MONTH, 1);
//        Date endTime = c.getTime(); //日期加1
//	    return salesService.findByCondition(java.sql.Date.valueOf(sdf.format(condition.getBeginTime())), endTime, "%"+condition.getGoodsName()+"%", condition.getPageable());
//		//return salesService.findByCondition("%"+condition.getGoodsName()+"%", condition.getPageable());
//	}
	
	
}
