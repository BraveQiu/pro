package com.mall.sales.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mall.sales.dao.ISalesDao;
import com.mall.sales.entity.SalesInfo;
import com.mall.sales.entity.dto.SalesDTO;
import com.mall.util.web.QueryCondition;

/**
 * 
 * @author Brave Qiu
 *
 */
@Service
@Transactional
public class SalesService implements ISalesService{
	@Autowired
	private ISalesDao salesDao;
	@Override
	public Page<SalesInfo> findAll(Pageable pageable) {
		
		return salesDao.findAll(pageable);
	}
	@Override
	public SalesInfo save(SalesInfo salesInfo) {
		
		return salesDao.save(salesInfo);
	}
//	@Transactional(readOnly=true)
//	public Page<SalesInfo> findByCondition(Date beginTime,Date endtime,String goodsName,Pageable pageable) {
//		
//		return salesDao.findByCondition(beginTime, endtime, goodsName, pageable);
//	}
	@Override
	public Page<SalesInfo> findByCondition(String goodsName, Pageable pageable) {
		return salesDao.findByCondition(goodsName, pageable);
	}
	@Override
	public Page<SalesDTO> findAll(Specification<SalesInfo> spec, Pageable pageable) {
		Page<SalesInfo> pages = salesDao.findAll(spec, pageable);
		List<SalesDTO> dtoLists = new ArrayList<SalesDTO>();
		for(SalesInfo entity:pages) {
			SalesDTO dto = new SalesDTO();
			SalesDTO.entityToDto(entity, dto);
			dtoLists.add(dto);
		}
		return new PageImpl<SalesDTO>(dtoLists, pageable, pages.getTotalElements());
	}
	
}
