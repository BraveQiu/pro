package com.mall.sales.service;
/**
 * 
 * @author Brave Qiu
 *
 */

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.mall.sales.entity.SalesInfo;
import com.mall.sales.entity.dto.SalesDTO;
import com.mall.util.web.QueryCondition;

public interface ISalesService {
	public Page<SalesInfo> findAll(Pageable pageable);
	public SalesInfo save(SalesInfo salesInfo);
	public Page<SalesInfo> findByCondition(String goodsName,Pageable pageable);
	
	public Page<SalesDTO> findAll(Specification<SalesInfo> spec,Pageable pageable);
}
