package com.mall.sales.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Component;

import com.mall.sales.entity.SalesInfo;

/**
 * 
 * @author Brave Qiu
 *
 */
@Component
public interface ISalesDao extends PagingAndSortingRepository<SalesInfo, Long>,JpaSpecificationExecutor<SalesInfo>{
//	@Query("from SalesInfo s where s.createTime >=?1 and s.createTime <= ?2 and s.goodsName like ?3")
//	public Page<SalesInfo> findAll(Specification<SalesInfo> spec, Pageable pageable);
	@Query("from SalesInfo s where s.goodsName like ?1")
	public Page<SalesInfo> findByCondition(String goodsName,Pageable pageable);
}
