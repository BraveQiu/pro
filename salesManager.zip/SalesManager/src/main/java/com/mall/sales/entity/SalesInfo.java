package com.mall.sales.entity;
/**
 * 销售信息统计
 * @author Brave Qiu
 *
 */

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
@Entity
@Table(name="t_salesInfo")
public class SalesInfo {
	private Long id;
	private String salesNumber;//单据号
	@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date createTime;//开单时间
	private String goodsId;//商品编号
	private String goodsName;//商品名称
	private float price;//商品单价
	private Integer salesCount;//销售数量
	private float total;//总金额
	private String salesHandler;//经办人
	
	//private float allTotal;//总收入
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}
	public String getSalesNumber() {
		return salesNumber;
	}
	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss",timezone = "GMT+8")
	public Date getCreateTime() {
		return createTime;
	}
	public String getGoodsId() {
		return goodsId;
	}
	public float getPrice() {
		return price;
	}
	public Integer getSalesCount() {
		return salesCount;
	}
	public float getTotal() {
		return total;
	}
	public String getSalesHandler() {
		return salesHandler;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setSalesNumber(String salesNumber) {
		this.salesNumber = salesNumber;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}
	
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public void setSalesCount(Integer salesCount) {
		this.salesCount = salesCount;
	}
	public void setTotal(float total) {
		this.total = total;
	}
	public void setSalesHandler(String salesHandler) {
		this.salesHandler = salesHandler;
	}
//	public float getAllTotal() {
//		return allTotal;
//	}
//	@Transient
//	public void setAllTotal(float allTotal) {
//		this.allTotal = allTotal;
//	}
	
	
}
