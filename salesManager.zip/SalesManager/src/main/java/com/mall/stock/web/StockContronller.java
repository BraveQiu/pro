package com.mall.stock.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
/**
 * 
 * @author Brave Qiu
 *
 */
import org.springframework.web.bind.annotation.ResponseBody;

import com.mall.sales.entity.SalesInfo;
import com.mall.sales.entity.dto.SalesQueryDTO;
import com.mall.stock.entity.StockInfo;
import com.mall.stock.entity.dto.StockDTO;
import com.mall.stock.entity.dto.StockQueryDTO;
import com.mall.stock.service.IStockService;
import com.mall.util.web.ExtjsPageable;
@Controller
@RequestMapping("/stock")
public class StockContronller {
	@Autowired
	private IStockService stockService;
	@RequestMapping("/findPage")
	public @ResponseBody Page<StockDTO> findAll(StockQueryDTO stockQueryDTO,ExtjsPageable pageable){
		Page<StockDTO> pages = stockService.findAll(StockQueryDTO.getWhereClause(stockQueryDTO), pageable.getPageable());
		List<StockDTO> lists = new ArrayList<>();
		List<StockDTO> listBack = new ArrayList<>();
		float allTotal = 0;
		for(int i=1;i<=pages.getTotalPages();i++) {
			pageable.setPage(i);
			Page<StockDTO> p = stockService.findAll(StockQueryDTO.getWhereClause(stockQueryDTO), pageable.getPageable());
			lists.addAll(p.getContent());
		}
		for(StockDTO s:lists) {
			allTotal = allTotal+s.getTotal();
		}
		StockDTO dto = new StockDTO();
		dto.setAllTotal(allTotal);
		
		listBack.add(dto);
		listBack.addAll(pages.getContent());
		return new PageImpl<>(listBack, pageable.getPageable(), pages.getTotalElements());
	}
}
