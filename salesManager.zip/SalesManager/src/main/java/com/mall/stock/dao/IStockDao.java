package com.mall.stock.dao;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.mall.stock.entity.StockInfo;


public interface IStockDao extends PagingAndSortingRepository<StockInfo, Long>,JpaSpecificationExecutor<StockInfo>{

}
