package com.mall.stock.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.mall.stock.entity.StockInfo;
import com.mall.stock.entity.dto.StockDTO;

public interface IStockService {
	public Page<StockDTO> findAll(Specification<StockInfo> spec,Pageable pageable);
	public void save(StockDTO dto);
}
