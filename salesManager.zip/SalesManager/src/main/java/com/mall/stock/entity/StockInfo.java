package com.mall.stock.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 进货信息
 * @author Brave Qiu
 *
 */
@Entity
@Table(name="t_stock")
public class StockInfo {
	private Long id;
	private String stockNumber;//进货单号
	private Date stockTime;//进货时间
	private String goodsId;//商品编号
	private String goodsName;//商品名称
	private float price;//商品单价
	private Integer stockCount;//进货数量
	private float total;//进货总额
	private String stockHandler;//经办人
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Long getId() {
		return id;
	}
	public String getStockNumber() {
		return stockNumber;
	}
	@JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss",timezone = "GMT+8")
	public Date getStockTime() {
		return stockTime;
	}
	public String getGoodsId() {
		return goodsId;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public float getPrice() {
		return price;
	}
	public Integer getStockCount() {
		return stockCount;
	}
	public float getTotal() {
		return total;
	}
	public String getStockHandler() {
		return stockHandler;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setStockNumber(String stockNumber) {
		this.stockNumber = stockNumber;
	}
	public void setStockTime(Date stockTime) {
		this.stockTime = stockTime;
	}
	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public void setStockCount(Integer stockCount) {
		this.stockCount = stockCount;
	}
	public void setTotal(float total) {
		this.total = total;
	}
	public void setStockHandler(String stockHandler) {
		this.stockHandler = stockHandler;
	}
	
}
