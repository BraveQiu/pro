package com.mall.stock.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mall.sales.entity.SalesInfo;
import com.mall.stock.dao.IStockDao;
import com.mall.stock.entity.StockInfo;
import com.mall.stock.entity.dto.StockDTO;

@Service
@Transactional
public class StockService implements IStockService{
	@Autowired
	private IStockDao stockDao;
	/**
	 * 封装成dto返回
	 */
	@Override
	public Page<StockDTO> findAll(Specification<StockInfo> spec, Pageable pageable) {
		Page<StockInfo> list = stockDao.findAll(spec, pageable);
		List<StockDTO> dtoLists = new ArrayList<StockDTO>();
		for(StockInfo entity:list.getContent()) {
			StockDTO dto = new StockDTO();
			StockDTO.entityToDto(entity, dto);
			dtoLists.add(dto);
		}
		return new PageImpl<StockDTO>(dtoLists, pageable, list.getTotalElements());
	}

	@Override
	public void save(StockDTO dto) {
		StockInfo entity = new StockInfo();
		BeanUtils.copyProperties(dto, entity);
		stockDao.save(entity);
	}
	
}
